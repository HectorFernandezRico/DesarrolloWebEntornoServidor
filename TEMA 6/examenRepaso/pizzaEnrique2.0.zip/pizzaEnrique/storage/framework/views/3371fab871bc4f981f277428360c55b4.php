<?php $__env->startSection('titulo', 'Editar'); ?>
<?php $__env->startSection('encabezado', 'EDITAR PIZZA'); ?>
<?php $__env->startSection('descripcion', 'Modifique los datos y presione "confirmar" para guardar los cambios.'); ?>
<?php $__env->startSection('contenido'); ?>
<div class="cuadro">
    <form action="<?php echo e(route('pizzas.update', $pizza->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <p>
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" value="<?php echo e(old('nombre') ? old('nombre') : $pizza->nombre); ?>" required>
        </p>
        
        <p>
            <label for="descripcion">Descripcion:</label>
            <input type="text" id="descripcion" name="descripcion" value="<?php echo e(old('descripcion') ? old('descripcion') : $pizza->descripcion); ?>" required>
        </p>
        
        <p>
            <label for="precio">Precio:</label>
            <input type="number" id="precio" name="precio" value="<?php echo e(old('precio') ? old('precio') : $pizza->precio); ?>" required>
        </p>
        
        <button type="submit">Actualizar</button>
    </form>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/Descargas/laravel/examenRepaso/pizzaEnrique/resources/views/editpizza.blade.php ENDPATH**/ ?>