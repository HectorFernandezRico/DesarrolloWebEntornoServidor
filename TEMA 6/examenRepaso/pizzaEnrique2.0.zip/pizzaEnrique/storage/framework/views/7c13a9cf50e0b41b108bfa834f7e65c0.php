<?php $__env->startSection('titulo', 'Pedidos'); ?>
<?php $__env->startSection('encabezado', 'PEDIDOS DE ' . $customer->nombre); ?>
<?php $__env->startSection('descripcion', 'Listado de los pedidos del cliente seleccionado.'); ?>
<?php $__env->startSection('contenido'); ?>
    <div class="botones"> 
        <a href="<?php echo e(route('clientes.index')); ?>"><button>Volver</button></a>
    </div>
    <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="cuadro">
            <p>
                Nº Pedido: <?php echo e($pedido->id); ?>

            </p>
            <p>
                Fecha: <?php echo e($pedido->fecha); ?>

            </p>
            <p>
                Hora: <?php echo e($pedido->hora); ?>

            </p>
            <p>
                Pizzas: <?php echo e($pedido->pizzas->pluck('nombre')->join(' ')); ?>

            </p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/Descargas/laravel/examenRepaso/pizzaEnrique/resources/views/pedidos.blade.php ENDPATH**/ ?>