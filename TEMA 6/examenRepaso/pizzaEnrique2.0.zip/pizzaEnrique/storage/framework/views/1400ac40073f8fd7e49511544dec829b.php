<?php $__env->startSection('titulo', 'Crear'); ?>
<?php $__env->startSection('encabezado', 'CREAR UNA PIZZA'); ?>
<?php $__env->startSection('descripcion', 'Añade los datos para crear una nueva pizza.'); ?>
<?php $__env->startSection('contenido'); ?>
<form action="<?php echo e(route('pizzas.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>    
    
    <p>
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" value="<?php echo e(old('nombre')); ?>" required>
    </p>
    
    <p>
        <label for="descripcion">Descripcion:</label>
        <textarea name="descripcion" id="descripcion">
            <?php echo e(old('descripcion')); ?>

        </textarea>
    </p>
    
    <p>
        <label for="precio">Precio:</label>
        <input type="number" id="precio" name="precio" value="<?php echo e(old('precio')); ?>" required>
    </p>
    
    <button type="submit">Añadir</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/Descargas/laravel/examenRepaso/pizzaEnrique/resources/views/crearpizza.blade.php ENDPATH**/ ?>