<?php $__env->startSection('titulo', 'Editar'); ?>
<?php $__env->startSection('encabezado', 'EDITAR CLIENTE'); ?>
<?php $__env->startSection('descripcion', 'Modifique los datos y presione "confirmar" para guardar los cambios.'); ?>
<?php $__env->startSection('contenido'); ?>
<div class="cuadro">
    <form action="<?php echo e(route('clientes.update', $customer->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <p>
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" value="<?php echo e(old('nombre') ? old('nombre') : $customer->nombre); ?>" required>
        </p>
        
        <p>
            <label for="direccion">Dirección:</label>
            <input type="text" id="direccion" name="direccion" value="<?php echo e(old('direccion') ? old('direccion') : $customer->direccion); ?>" required>
        </p>
        
        <p>
            <label for="telefono">Teléfono:</label>
            <input type="tel" id="telefono" name="telefono" value="<?php echo e(old('telefono') ? old('telefono') : $customer->telefono); ?>" required>
        </p>
        
        <p>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo e(old('email') ? old('email') : $customer->email); ?>" required>
        </p>
        
        <button type="submit">Actualizar</button>
    </form>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/Descargas/laravel/examenRepaso/pizzaEnrique/resources/views/edit.blade.php ENDPATH**/ ?>