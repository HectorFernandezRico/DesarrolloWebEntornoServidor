<?php $__env->startSection('titulo', 'Pizzas'); ?>
<?php $__env->startSection('encabezado', 'Pizzas'); ?>
<?php $__env->startSection('descripcion', 'Página listando todos las pizzas y con dos opciones.'); ?>
<?php $__env->startSection('contenido'); ?>
    <div class="botones">
        <a href="<?php echo e(route('pizzas.create')); ?>"><button>Añadir</button></a>
        <a href="<?php echo e(route('clientes.index')); ?>"><button>Clientes</button></a>
        <a href="<?php echo e(route('pizzas.index')); ?>"><button>Pizzas</button></a>
    </div>
    <?php echo e($pizzas->links('pagination::bootstrap-5')); ?>

    <?php $__currentLoopData = $pizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="cuadro">
            <p>
                Nombre: <?php echo e($pizza->nombre); ?>

            </p>
            <p>
                Descripcion: <?php echo e($pizza->descripcion); ?>

            </p>
            <p>
                Precio: <?php echo e($pizza->precio); ?>

            </p>
            <div class="botones">
                <form action="<?php echo e(route('pizzas.edit', $pizza->id)); ?>" method="get">
                    <?php echo csrf_field(); ?>
                    <input type="submit" value="EDITAR">
                </form>
                <form action="<?php echo e(route('pizzas.destroy', $pizza->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <input type="submit" value="BORRAR">
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($pizzas->links('pagination::bootstrap-5')); ?>


    <?php if(session('mensaje')): ?>
        <script>
            alert("<?php echo e(session('mensaje')); ?>");
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/Descargas/laravel/examenRepaso/pizzaEnrique/resources/views/pizzas.blade.php ENDPATH**/ ?>