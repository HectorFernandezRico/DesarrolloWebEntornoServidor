<?php $__env->startSection('titulo', 'Home'); ?>
<?php $__env->startSection('encabezado', 'MENÚ'); ?>
<?php $__env->startSection('descripcion', 'Página principal listando todos los clientes y con dos opciones.'); ?>
<?php $__env->startSection('contenido'); ?>
    <div class="botones">
        <a href="<?php echo e(route('clientes.create')); ?>"><button>Añadir</button></a>
        <a href="<?php echo e(route('clientes.index')); ?>"><button>Clientes</button></a>
        <a href="/"><button>Pizzas</button></a>
    </div>
    <?php echo e($customers->links('pagination::bootstrap-5')); ?>

    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="cuadro">
            <p>
                Nombre: <?php echo e($customer->nombre); ?>

            </p>
            <p>
                Dirección: <?php echo e($customer->direccion); ?>

            </p>
            <p>
                Teléfono: <?php echo e($customer->telefono); ?>

            </p>
            <p>
                Email: <?php echo e($customer->email); ?>

            </p>
            <div class="botones">
                <form action="<?php echo e(route('clientes.edit', $customer->id)); ?>" method="get">
                    <?php echo csrf_field(); ?>
                    <input type="submit" value="EDITAR">
                </form>
                <form action="<?php echo e(route('clientes.delete', $customer->id)); ?>" method="get">
                    <?php echo csrf_field(); ?>
                    <input type="submit" value="BORRAR">
                </form>
                <form action="<?php echo e(route('clientes.delete', $customer->id)); ?>" method="get">
                    <?php echo csrf_field(); ?>
                    <input type="submit" value="GESTIONAR PEDIDOS">
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($customers->links('pagination::bootstrap-5')); ?>


    <?php if(session('mensaje')): ?>
        <script>
            alert("<?php echo e(session('mensaje')); ?>");
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/laravel/examenRepaso/pizzaEnrique/resources/views/home.blade.php ENDPATH**/ ?>