<?php $__env->startSection('titulo', 'Crear'); ?>
<?php $__env->startSection('encabezado', 'CREAR UN CLIENTE'); ?>
<?php $__env->startSection('descripcion', 'Añade los datos para crear un nuevo cliente.'); ?>
<?php $__env->startSection('contenido'); ?>
<form action="<?php echo e(route('clientes.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>    
    
    <p>
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" value="<?php echo e(old('nombre')); ?>" required>
    </p>
    
    <p>
        <label for="direccion">Dirección:</label>
        <input type="text" id="direccion" name="direccion" value="<?php echo e(old('direccion')); ?>" required>
    </p>
    
    <p>
        <label for="telefono">Teléfono:</label>
        <input type="tel" id="telefono" name="telefono" value="<?php echo e(old('telefono')); ?>" required>
    </p>
    
    <p>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required>
    </p>
    
    <button type="submit">Añadir</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/Descargas/laravel/examenRepaso/pizzaEnrique/resources/views/crear.blade.php ENDPATH**/ ?>