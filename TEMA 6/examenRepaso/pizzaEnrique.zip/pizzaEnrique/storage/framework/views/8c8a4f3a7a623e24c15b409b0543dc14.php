<?php $__env->startSection('titulo', 'Borrar'); ?>
<?php $__env->startSection('encabezado', 'CONFIRMAR BORRADO'); ?>
<?php $__env->startSection('descripcion', 'Presiona al botón para borrar este cliente de la base de datos.'); ?>
<?php $__env->startSection('contenido'); ?>
    <div class="cuadro">
        <p>
            Nombre: <?php echo e($customer->nombre); ?>

        </p>
        <p>
            Dirección: <?php echo e($customer->direccion); ?>

        </p>
        <p>
            Teléfono: <?php echo e($customer->telefono); ?>

        </p>
        <p>
            Email: <?php echo e($customer->email); ?>

        </p>
        <form action="<?php echo e(route('clientes.destroy', $customer->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <input type="submit" value="CONFIRMAR">
        </form>
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/laravel/examenRepaso/pizzaEnrique/resources/views/confirmar.blade.php ENDPATH**/ ?>