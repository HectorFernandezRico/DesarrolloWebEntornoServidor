<?php

use App\Http\Controllers\PizzaController;
use Illuminate\Support\Facades\Route;

Route::resource("/clientes", PizzaController::class);
Route::get("/clientes/{customer:id}/delete", [PizzaController::class,'confirmar_borrado'])->name('clientes.delete');
Route::get('/pedidos/{customer:id}', [PizzaController::class,'gestionar_pedidos'])->name('clientes.pedidos');