<?php $__env->startSection('container'); ?>

<div class="d-flex justify-content-center align-items-center vh-100 flex-wrap">
    <h1 class="text-center">BIENVENIDOS AL MENÚ!!</h1>
    <h3 class="text-center align-self-start">Explore la página mediante los botones de la barra de navegación</h3>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.miniweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\enri777\Documents\composerPhp\DesarrolloWebEntornoServidor\TEMA 6\Aplication2\resources\views/menu.blade.php ENDPATH**/ ?>