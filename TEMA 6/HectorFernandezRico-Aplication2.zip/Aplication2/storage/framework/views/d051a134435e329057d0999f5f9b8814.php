

<?php $__env->startSection('container'); ?>
    <div class="container">
        <h2 class="text-center mb-4">Formulario de Solicitud de Viaje</h2>

        <form action="<?php echo e(url('ruta_del_formulario')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre</label>
                <input type="text" class="form-control" id="nombre" name="nombre" required>
            </div>

            <div class="mb-3">
                <label for="apellido" class="form-label">Apellido</label>
                <input type="text" class="form-control" id="apellido" name="apellido" required>
            </div>

            <div class="mb-3">
                <label for="telefono" class="form-label">Teléfono</label>
                <input type="tel" class="form-control" id="telefono" name="telefono" required>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Correo Electrónico</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>

            <div class="mb-3">
                <label for="pais" class="form-label">País que quiere visitar</label>
                <input type="text" class="form-control" id="pais" name="pais" required>
            </div>

            <div class="mb-3">
                <label for="fecha_ida" class="form-label">Fecha de ida</label>
                <input type="date" class="form-control" id="fecha_ida" name="fecha_ida" required>
            </div>

            <div class="mb-3">
                <label for="fecha_vuelta" class="form-label">Fecha de vuelta</label>
                <input type="date" class="form-control" id="fecha_vuelta" name="fecha_vuelta" required>
            </div>

            <div class="text-center">
                <button type="submit" class="btn btn-primary">Enviar</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.miniweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\enri777\Documents\composerPhp\DesarrolloWebEntornoServidor\TEMA 6\Aplication2\resources\views/inscripcion.blade.php ENDPATH**/ ?>