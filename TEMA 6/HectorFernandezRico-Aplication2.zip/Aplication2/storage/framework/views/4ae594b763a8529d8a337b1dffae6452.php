<?php $__env->startSection('container'); ?>
    <?php $__currentLoopData = $lugares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais => $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h2 class="titulo"><?php echo e($pais); ?></h2>
    <div class="container d-flex justify-content-between">
        <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card" style="width: 18rem;">
                <img src="<?php echo e($dato[3]); ?>" class="card-img-top" alt="<?php echo e($dato[0]); ?>">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($dato[0]); ?></h5>
                    <p class="card-text"><?php echo e($dato[1]); ?></p>
                    <a href="<?php echo e($dato[2]); ?>" class="btn btn-primary"><i>Buscar...</i></a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.miniweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\enri777\Documents\composerPhp\DesarrolloWebEntornoServidor\TEMA 6\Aplication2\resources\views/visitas.blade.php ENDPATH**/ ?>