@extends('layouts.miniweb')
@section('container')

<div class="d-flex justify-content-center align-items-center vh-100 flex-wrap">
    <h1 class="text-center">BIENVENIDOS AL MENÚ!!</h1>
    <h3 class="text-center align-self-start">Explore la página mediante los botones de la barra de navegación</h3>
</div>


@endsection