<div class="borde">
    
    <h2 class='tgrande'><?php echo e($thread->titulo); ?></h2>
    <div>
        
    Categoría:
        <a href="<?php echo e(route('page.category',$thread->category->slug)); ?>" class="separado">
            <?php echo e($thread->category->nombre); ?>

        </a>
        <br>
        Etiquetas:
        <span>
            <?php $__currentLoopData = $thread->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="separado" href="<?php echo e(route('page.tag',$tag->slug)); ?>">
                    <?php echo e($tag->nombre); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </span>
        <br>
        Usuario:
        <span>
            <a class="separado" href="<?php echo e(route ('page.user', $thread->user->id)); ?>">
                <?php echo e($thread->user->name); ?>

            </a>
        </span>
        <p>
            <?php echo e($thread->comments->count()); ?> comentarios
            <span><a href="<?php echo e(route ('page.thread', $thread->slug)); ?>">Ver &rarr;</a></span>
        </p>
    </div>
</div><?php /**PATH /home/alumno/desarollo/foro/resources/views/_item.blade.php ENDPATH**/ ?>