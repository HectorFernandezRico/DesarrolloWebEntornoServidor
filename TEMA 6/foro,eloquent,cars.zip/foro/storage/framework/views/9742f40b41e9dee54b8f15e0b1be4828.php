<?php $__env->startSection('title', $thread->titulo); ?>

<?php $__env->startSection('description', 'Datos de la pregunta '. $thread->body); ?>

<?php $__env->startSection('content'); ?>
<div class="borde">
    <?php echo e($thread->body); ?>

    </div>
    <div>
    Etiquetas:
    <span>
    <?php $__currentLoopData = $thread->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('page.tag', $tag->slug)); ?>" class="separado">
    <?php echo e($tag->nombre); ?>

    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </span>
    </div>
    <br>
    <div>
    <h2>
    <?php echo e($thread->comments->count()); ?> comentarios
    <span>
    <a href="<?php echo e(route('page.thread', $thread->slug)); ?>">
    Ver &rarr;
    </a>
    </span>
    </h2>
    <?php $__currentLoopData = $thread->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- AQUI SE OBTIENE LA INFORMACIÓN DE UN COMENTARIO -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/desarollo/foro/resources/views/thread.blade.php ENDPATH**/ ?>