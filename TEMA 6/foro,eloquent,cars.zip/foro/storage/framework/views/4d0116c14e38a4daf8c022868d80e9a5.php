<?php $__env->startSection('title', $tag->nombre); ?>

<?php $__env->startSection('description', 'Los mejores hilos sobre '. $tag->nombre); ?>

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('_item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/desarollo/foro/resources/views/tag.blade.php ENDPATH**/ ?>