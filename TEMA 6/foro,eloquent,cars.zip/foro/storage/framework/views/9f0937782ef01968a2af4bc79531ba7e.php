<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('description', 'Bienvenido al foro de comida saludable y ecologica'); ?>

<?php $__env->startSection('content'); ?>

<?php echo e($threads->links('pagination::bootstrap-5')); ?>

<?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('_item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($threads->links('pagination::bootstrap-5')); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/desarollo/foro/resources/views/home.blade.php ENDPATH**/ ?>