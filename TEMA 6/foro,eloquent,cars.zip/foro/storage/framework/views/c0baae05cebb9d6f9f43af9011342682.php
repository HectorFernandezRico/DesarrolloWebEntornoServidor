<?php $__env->startSection('title', $category->nombre); ?>

<?php $__env->startSection('description', 'Los mejores hilos sobre '. $category->nombre); ?>

<?php $__env->startSection('content'); ?>
    <h1>Formulario</h1>
    <form action="<?php echo e(route('grabar')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <p>
            <label for="autor">Autor: </label>
            <input type="text" name="autor" id="autor" value="<?php echo e(old('autor')); ?>">
        </p>
        <p>
            <label for="autor">Titulo: </label>
            <input type="text" name="titulo" id="titulo" value="<?php echo e(old('titulo')); ?>">
        </p>
        <p>
            <label for="cuerpo">Cuerpo del mensaje: </label>
            <textarea name="cuerpo" id="cuerpo" cols="30" rows="10">
                <?php echo e(old('cuerpo')); ?>

            </textarea>
        </p>
        <p>
            <input type="submit" value="Enviar">
        </p>
        <?php if(session('mensaje')): ?>
            <?php echo e(session('mensaje')); ?>

        <?php endif; ?>
        

        <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['autor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/desarollo/foro/resources/views/formulario.blade.php ENDPATH**/ ?>