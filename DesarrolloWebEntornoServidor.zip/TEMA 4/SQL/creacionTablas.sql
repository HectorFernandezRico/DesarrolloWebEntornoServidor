insert into tienda (nombre, telefono)
values
('El corte ingles' , '22222'),
('Decathlon', '323232332'),
('El chino de la esquina', '34343434');