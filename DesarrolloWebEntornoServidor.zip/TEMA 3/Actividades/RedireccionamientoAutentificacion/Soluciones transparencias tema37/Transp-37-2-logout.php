<?php
  session_start(); // Siempre !!
  session_destroy();
  header("Location: Transp-37-2-app.php");
?>
