<?php
/*
    $a = 3.2;

    echo $a/2;

    echo "<br>";

    $n1 = "34hhhh";

    echo $n1 + 3;
    echo "<br>";
*/

    $numero = rand(1,10);
    echo "<br>"; echo "<br>";
    echo $numero;
    echo "<br>";
    
?>