<?php
  $titulo="Aquí tu título específico";
  include_once("cabecera.php");
?>
<?php
  // AQUÍ TU CÓDIGO ESPECÍFICO
?>

<?php
  include_once("pie.html");
?>
