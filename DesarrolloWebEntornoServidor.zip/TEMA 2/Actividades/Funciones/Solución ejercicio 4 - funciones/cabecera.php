<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=Device-width, initial-scale=1.0">
    <title><?=$titulo?></title>
  </head>
  <body>
