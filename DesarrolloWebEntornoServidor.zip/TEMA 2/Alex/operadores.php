<?php
    $a = "3";
    $b = 3;

    if ($a == $b) echo"son iguales";
    else echo "no son iguales";
    echo "<br>";


    if ($a && $b) echo "es true";
    else echo "es false";
    echo "<br>";