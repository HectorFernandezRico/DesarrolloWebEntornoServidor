<?php

    $a = 56;
    $b = 12;
    $c = $a / $b;
    echo "<br> C = $c";

    $d = "100" + 36.5 + true;
    echo "<br> D= " . $d;

    $e = (int) 9.9 - 1;
    echo "<br> E= $e";

    $f = "hola" . 25;
    echo "<br> F= $f";

    $h = true + false;
    echo "<br> H= $h";
    echo "<br>false como string= " . (string) false;
    echo "<br>false como int= " . (int) false;

    $g = "hola" + 25;
    echo "<br> G= $g";