<?php
    $x = 3;
    $y = 4 + $x;

    echo $y;
    echo "<br>";

    const PI = 3.141592;
    echo PI;
    echo "<br>";

    $cadena = "HOLA, el simbolo de arroba es \"@\"";
    $cadena = 'HOLA, el simbolo de arroba es "@"';
    $boolean = false;
    $vacio = null;

    echo $boolean;
    echo "<br>";
    echo $vacio;
    echo "<br>";
    echo $cadena;
    echo "<br>";

    echo "Hola $cadena";
    echo "<br>";
    echo 'Hola $cadena';
    echo "<br>";

?>