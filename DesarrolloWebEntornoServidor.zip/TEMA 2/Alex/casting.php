<?php

$a = 3;

echo (int) $a/2;
echo "<br>";

$n1 = "hhhh";

echo $n1 + 3;
echo "<br>";