<?php 
    $a = "ejejiif";
    $b = 20;
    if ($a != $b) echo "son distintos";
    else echo "no son distintos";
    echo "<br>";

    if ($a && $b) echo "es true";
    else echo "es false";
    echo "<br>";
?>