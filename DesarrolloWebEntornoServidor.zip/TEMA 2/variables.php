<?php
    $x = 3;
    $y = 2 + $x;

    echo $y;
    echo "<br>";

    const PI = 3.141592;
    echo PI;
    echo "<br>";

    $cadena = "HOLA, el símbolo de arroba es \"@\"";
    $cadena = 'HOLA, el símbolo de arroba es "@"';
    echo $cadena;
    echo '<br>';
    echo "hola $cadena";
    echo "<br>";

?>