<?php $__env->startSection('name','Formulario de alta'); ?>
<?php $__env->startSection('title','Formulario de alta'); ?>

<?php $__env->startSection('section'); ?>
<div>
<form action="<?php echo e(route('clientes.alta')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <p>
        <label for="razonsocial">Razon social:</label>
        <input type="text" name="razonsocial" id="razonsocial" value="<?php echo e(old('razonsocial')); ?>">
    </p>
    <p>
        <label for="pcontacto">Persona contacto:</label>
        <input type="text" name="pcontacto" id="pcontacto" value="<?php echo e(old('pcontacto')); ?>">
    </p>
    <p>
        <label for="telefono">Telefono:</label>
        <input type="text" name="telefono" id="telefono" value="<?php echo e(old('telefono')); ?>">
    </p>
    <p>
        <label for="email">Email:</label>
        <input type="text" name="email" id="email" value="<?php echo e(old('email')); ?>">
    </p>
    <p>
        <label for="direccion">Direccion:</label>
        <input type="text" name="direccion" id="direccion" value="<?php echo e(old('direccion')); ?>">
    </p>

    <input type="submit" value="Añadir" name="anadir">
</form>
</div>
<a href="<?php echo e(route('clientes.home')); ?>"><button>Volver</button></a>

<?php if(session('mensaje')): ?>
    <p class="azul"><?php echo e(session('mensaje')); ?></p>
<?php endif; ?>
<?php $__errorArgs = ['razonsocial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="rojo"><?php echo e($message); ?></p>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php $__errorArgs = ['pcontacto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="rojo"><?php echo e($message); ?></p>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="rojo"><?php echo e($message); ?></p>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="rojo"><?php echo e($message); ?></p>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="rojo"><?php echo e($message); ?></p>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/alumno/Escritorio/examenhector/resources/views/formularioAlta.blade.php ENDPATH**/ ?>