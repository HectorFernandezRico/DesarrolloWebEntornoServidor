<?php $__env->startSection('name','Pagina principal'); ?>
<?php $__env->startSection('title','Pagina principal'); ?>

<?php $__env->startSection('section'); ?>

<?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div>

<p>Razon social : <?php echo e($cliente->razonsocial); ?></p>
<p>Pcontacto: <?php echo e($cliente->pcontacto); ?></p>
<p>telefono: <?php echo e($cliente->telefono); ?></p>
<p>email: <?php echo e($cliente->email); ?></p>
<p>direccion: <?php echo e($cliente->direccion); ?></p>
</div>    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

    
<?php echo $__env->make('layouts.plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/alumno/Escritorio/examenhector/resources/views/principal.blade.php ENDPATH**/ ?>