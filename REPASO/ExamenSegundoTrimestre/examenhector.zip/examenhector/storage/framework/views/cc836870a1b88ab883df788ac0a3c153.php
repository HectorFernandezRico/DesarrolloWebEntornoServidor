<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('plantilla.css')); ?>">
</head>
<body>
    <h1><?php echo $__env->yieldContent('name'); ?></h1>
    <a href="<?php echo e(route('clientes.home')); ?>"><button>Home</button></a>
    <a href="<?php echo e(route('formulario.alta')); ?>"><button>Alta</button></a>

  
    <?php echo $__env->yieldContent('section'); ?>

</body>
</html><?php /**PATH /home/alumno/Escritorio/examenhector/resources/views/layouts/plantilla.blade.php ENDPATH**/ ?>